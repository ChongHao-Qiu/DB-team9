import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _15ca5bf0 = () => interopDefault(import('../pages/actor/index.vue' /* webpackChunkName: "pages/actor/index" */))
const _1f33bc01 = () => interopDefault(import('../pages/collection/index.vue' /* webpackChunkName: "pages/collection/index" */))
const _6212feb9 = () => interopDefault(import('../pages/login.vue' /* webpackChunkName: "pages/login" */))
const _3def4cfa = () => interopDefault(import('../pages/movie/index.vue' /* webpackChunkName: "pages/movie/index" */))
const _826d18fa = () => interopDefault(import('../pages/register.vue' /* webpackChunkName: "pages/register" */))
const _b867f646 = () => interopDefault(import('../pages/ucenter/index.vue' /* webpackChunkName: "pages/ucenter/index" */))
const _c0749320 = () => interopDefault(import('../pages/actor/_id.vue' /* webpackChunkName: "pages/actor/_id" */))
const _3c817397 = () => interopDefault(import('../pages/director/_id.vue' /* webpackChunkName: "pages/director/_id" */))
const _12d4e0ab = () => interopDefault(import('../pages/movie/_id.vue' /* webpackChunkName: "pages/movie/_id" */))
const _04a1b50c = () => interopDefault(import('../pages/movie/_id copy.vue' /* webpackChunkName: "pages/movie/_id copy" */))
const _47d0c696 = () => interopDefault(import('../pages/movie/_id1.vue' /* webpackChunkName: "pages/movie/_id1" */))
const _6765f145 = () => interopDefault(import('../pages/orders/_oid.vue' /* webpackChunkName: "pages/orders/_oid" */))
const _0659d6b3 = () => interopDefault(import('../pages/pay/_pid.vue' /* webpackChunkName: "pages/pay/_pid" */))
const _32cb9390 = () => interopDefault(import('../pages/player/_vid.vue' /* webpackChunkName: "pages/player/_vid" */))
const _cf2948bc = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/actor",
    component: _15ca5bf0,
    name: "actor"
  }, {
    path: "/collection",
    component: _1f33bc01,
    name: "collection"
  }, {
    path: "/login",
    component: _6212feb9,
    name: "login"
  }, {
    path: "/movie",
    component: _3def4cfa,
    name: "movie"
  }, {
    path: "/register",
    component: _826d18fa,
    name: "register"
  }, {
    path: "/ucenter",
    component: _b867f646,
    name: "ucenter"
  }, {
    path: "/actor/:id",
    component: _c0749320,
    name: "actor-id"
  }, {
    path: "/director/:id?",
    component: _3c817397,
    name: "director-id"
  }, {
    path: "/movie/:id",
    component: _12d4e0ab,
    name: "movie-id"
  }, {
    path: "/movie/:id%20copy",
    component: _04a1b50c,
    name: "movie-id copy"
  }, {
    path: "/movie/:id1",
    component: _47d0c696,
    name: "movie-id1"
  }, {
    path: "/orders/:oid?",
    component: _6765f145,
    name: "orders-oid"
  }, {
    path: "/pay/:pid?",
    component: _0659d6b3,
    name: "pay-pid"
  }, {
    path: "/player/:vid?",
    component: _32cb9390,
    name: "player-vid"
  }, {
    path: "/",
    component: _cf2948bc,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
