import request from '@/utils/request'

export default{
    getListBanner(){
        return request({
            url:`/educms/bannerfront/getAllBanner`,
            method:'get'
        })
    }
}