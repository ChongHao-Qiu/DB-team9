<template>
    <div class="sign" >
        <div class="logo">
            <a href="/" title="mymovie">
            <img src="~/assets/img/logo.png" width="100%" alt="mmymovie">
          </a>
        </div>

        <nuxt/>
    </div>
</template>
<!-- <template>
    <div class="sign" style="display: flex; flex-direction: column; align-items: center;">
        <div class="logo" style="margin-bottom: 50px;">
            <img src="~/assets/img/logo.png"  width="20%" alt="logo">
        </div>

        <nuxt style="width: 100%; text-align: center;"/>
    </div>
</template> -->